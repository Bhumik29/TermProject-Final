#Citations:
#I got the TKinter run function from the course website, from https://www.cs.cmu.edu/~112/notes/notes-animations-part2.html
#I got the mode/screens code from the course website, from https://www.cs.cmu.edu/~112/notes/notes-animations-demos.html
#I got all the graphics for the tiles that I made from a website called Canva, https://www.canva.com, all graphics that I dont cite I got from this website
# I got the board image from http://www.hollywood.com/tv/arrested-development-game-of-life-59094588/
# I got the start screen image from https://store.steampowered.com/app/403120/THE_GAME_OF_LIFE/
# I got the red car image from http://www.mottarappresentanze.it/servizi-assicurativi-e-finanziari/assicurazioni/005-racing/
#I got the blue car image from http://www.clker.com/clipart-blue-car-6.html
#I got the game over image from https://www.vectorstock.com/royalty-free-vector/you-win-poster-with-prize-cup-vector-17052074
#I got the  example card image from https://www.students.org/2015/06/10/the-game-of-college-life-3-college-pitfalls/
#I got the Grad cap from https://www.iconfinder.com/icons/2750434/caps_college_education_graduate_hat_toga_hat_icon
#I got the Mercedes from https://www.digitaltrends.com/car-reviews/2019-mercedes-amg-gt-4-door-coupe-review/
#I got the Used car from https://www.autotrader.com/best-cars/10-good-used-cars-under-10000-216226



from tkinter import *
import random 
import math

####################################
# init
####################################

def init(data):
    data.mode = "startScreen"
    data.startScreenImg=PhotoImage(file="start.gif")
    data.board=PhotoImage(file="L I F E.gif")
    data.player=PhotoImage(file="rsz_lifecar.gif")
    data.computer=PhotoImage(file="rsz_bluecar.gif")
    data.gameOverImg=PhotoImage(file="GameOver.gif")
    data.level=None
    data.compCount=0
    data.spinner=PhotoImage(file="spinner.gif")
    data.pos1stList=[(292,675), (228,691), (182,722), (232,750), (298,749), (358,747), (419,753), (481,740), (548,730), (548,620), (545,556), (503,611), (459,643), (422,599), (464,525), (519,491), (561,453), (524,406), (435,410), (392,411), (330,410), (258,412), (192,389), (117,390), (56,360), (50,288), (45,159), (97,65), (138,35), (199,43), (232,131), (264,161), (295, 161), (376,156), (429,111), (508,76), (556,232), (559,326), (532,369), (472,372), (405,366), (362,363), (287,359), (227,344), (267,316), (300,284), (386,278), (441,258), (452,192), (478, 242), (518,223), (466,128), (390,63), (313,32), (239,41), (190,109), (189,203), (142,285), (89,335), (144,336), (182,427), (134,464), (91,458), (33,471), (20,537), (21,619), (21,695), (56,744), (110,728), (60,662), (110,634)]
    
    educationCard=PhotoImage(file="educationCard.gif")
    newSchoolSup=PhotoImage(file="NewSchoolSupplies.gif")
    springBreak=PhotoImage(file="SpringBreak.gif")
    danceContest=PhotoImage(file="DanceContest.gif")
    computerBroke=PhotoImage(file="computerbroke.gif")
    gradparty=PhotoImage(file="gradparty.gif")
    jobCollege=PhotoImage(file="JobSearchCollege.gif")
    payDay=PhotoImage(file="payDay.gif")
    hobby1=PhotoImage(file="Hobby.gif")
    eoyBonus=PhotoImage(file="EOYbonus.gif")
    newCar=PhotoImage(file="NewCar.gif")
    wedding=PhotoImage(file="Wedding.gif")
    visitParents=PhotoImage(file="visitparents.gif")
    nightSchool=PhotoImage(file="nightSchool.gif")
    brokeLeg=PhotoImage(file="BrokeLeg.gif")
    raffle=PhotoImage(file="Raffle.gif")
    found100=PhotoImage(file="Found$100.gif")
    children=PhotoImage(file="Children.gif")
    familyVac=PhotoImage(file="FamilyVacation.gif")
    kidsSchool=PhotoImage(file="KidsSchool.gif")
    carBroke=PhotoImage(file="CarBroke.gif")
    raisesal=PhotoImage(file="Raise.gif")
    house=PhotoImage(file="House.gif")
    familyPet=PhotoImage(file="FamilyPet.gif")
    leakyRoof=PhotoImage(file="LeakyRoof.gif")
    concert=PhotoImage(file="ConcertTix.gif")
    homeinsurance=PhotoImage(file="HomeInsurance.gif")
    famVac2=PhotoImage(file="FamVacation2.gif")
    stocks=PhotoImage(file="Stocks.gif")
    excercise=PhotoImage(file="Exercise.gif")
    hail=PhotoImage(file="HailDamage.gif")
    hobby2=PhotoImage(file="Hobby2.gif")
    bet=PhotoImage(file="SBBet.gif")
    sweet16=PhotoImage(file="Sweet16.gif")
    payforKids=PhotoImage(file="PayForKids.gif")
    triath=PhotoImage(file="Triathalon.gif")
    charity=PhotoImage(file="Charity.gif")
    sued=PhotoImage(file="Sued.gif")
    flu=PhotoImage(file="flu.gif")
    childmarried=PhotoImage(file="childmarried.gif")
    thanks=PhotoImage(file="Thanksgiving.gif")
    extra200=PhotoImage(file="Extra200.gif")
    babyShower=PhotoImage(file="BabyShower.gif")
    charityChoice=PhotoImage(file="charitychoice.gif")
    roofdam=PhotoImage(file="roofdamage.gif")
    newPet2=PhotoImage(file="NewPet2.gif")
    lottery=PhotoImage(file="Lottery.gif")
    pickstock=PhotoImage(file="PickStock.gif")
    grandkidgift=PhotoImage(file="grandkidsgifts.gif")
    retire=PhotoImage(file="Retire.gif")
    housechanging=PhotoImage(file="HouseChanging.gif")
    finalVac=PhotoImage(file="finalvacation.gif")
    foundmoney=PhotoImage(file="foundmoney.gif")
    investment=PhotoImage(file="investment.gif")
    data.helpBack=PhotoImage(file="help.gif")
    data.sideBar=PhotoImage(file="sidebar.gif")
    data.tempPlayerIndex=0
    
    data.pics1stPath=[educationCard, newSchoolSup, springBreak, danceContest, computerBroke, gradparty, jobCollege, payDay, hobby1, eoyBonus, newCar, payDay, wedding, visitParents, nightSchool, brokeLeg, payDay, raffle, children, payDay, found100, familyVac, payDay, kidsSchool, carBroke, house, raisesal, payDay, familyPet, concert, homeinsurance, payDay, leakyRoof, famVac2, payDay, hail, charityChoice, payDay, stocks, excercise, payforKids, payDay, sweet16, bet, payDay, triath, charity, sued, flu, childmarried, thanks, payDay, extra200, babyShower, payDay, charityChoice, roofdam, newPet2, payDay, lottery, payDay, pickstock, payDay, grandkidgift, finalVac, payDay, foundmoney, investment, payDay, found100, retire]
    
    data.money1stPath= [(-40000, 50000), (-5000, -5000), (-1000, 0), (500, 0), (-1000, 0), (-1000, -500), (0,0), (0, 0), (-2000, -1000), (1000, 1000), (-30000, -10000), (0,0), (-10000, -5000), (-1000, -500), (-10000, 0), (-1000, -1000), (1000, 1000), (500, 500), (0, 0), (1000, 1000), (100, 100), (-5000, -2000), (1000, 1000), (-5000, 0), (-1000, -1000), (-30000, -10000), (2000, 2000), (1000, 1000), (-500, -100), (-500, -500), (-2000, 0), (1000, 1000), (-1000, -1000), (-2000, -500), (1000, 1000), (-2000, -2000), (-300, -200), (1000, 1000), (1000, 1000), (-500, -300), (-40000, -20000), (1000, 1000), (-500, -500), (500, 500), (1000, 1000), (500, 500), (-1000, -1000), (-6000, -3000), (-200, -200), (-5000, -200), (-500, -500), (1000, 1000), (200, 200), (100, 100), (1000, 1000), (-300, -200), (-1000, -1000), (-300, -100), (1000, 1000), (5000, 5000), (1000, 1000), (2000, 4000), (1000, 1000), (-200, -200), (-2000, -1000), (1000, 1000), (100, 100), (2000, 1000), (1000, 1000), (100, 100), (-30000, -10000)]
    
    data.dec1stPath= [("Go to College", "Get a job"), ("Buy new supplies", "Buy new supplies"), ("Travel with friends", "Stay home"), ("Won a dance contest", "Won a dance contest"), ("Buy a new computer", "Use the computer lab"), ("Take a trip", "Celebrate at home"), ("some job", "some job"), ("Pay Day", "Pay Day"), ("Music", "Art"), ("EOY Bonus", "EOY Bonus"), ("Luxury Car", "Used Car"), ("Pay Day", "Pay Day"), ("Large Wedding", "Casual Wedding"), ("Fly", "Road Trip"), ("Go to Night School", "Not go to night school"), ("Broke leg", "Broke Leg"), ("Pay Day", "Pay Day"), ("Won raffle", "Won raffle"), ("some children", "some children"), ("Pay Day", "Pay Day"), ("Found $100", "Found $100"), ("Disney", "Beach"), ("Pay Day", "Pay Day"), ("Private School", "Public School"), ("Car Broke", "Car Broke"), ("House", "Apartment"), ("Raise", "Raise"), ("Pay Day", "Pay Day"), ("Dog", "Fish"), ("Concert Tickets", "Concert Tickets"), ("Buy Home insurance", "Not buy home insurance"), ("Pay Day", "Pay Day"), ("Leaky Roof", "Leaky Roof"), ("Paris", "Theme park"), ("Pay Day", "Pay Day"), ("Hail", "Hail"), ("Bake Sale", "Run a marathon"), ("Pay Day", "Pay Day"), ("Stocks", "Stocks"), ("Gym", "Yoga"), ("Pay All", "Pay Half"), ("Pay Day", "Pay Day"), ("Sweet 16", "Sweet 16"), ("Won bet", "Won bet"), ("Pay Day", "Pay Day"), ("Triathalon", "Triathalon"), ("Charity", "Charity"), ("Hire a lawyer", "Pay settlement"), ("Flu", "Flu"), ("Loan", "Dishes"), ("Thanksgiving", "Thanksgiving"), ("Pay Day", "Pay Day"), ("Found $200", "Found $200"), ("Baby Shower", "Baby Shower"), ("Pay Day", "Pay Day"), ("Bake Sale", "Marathon"), ("Roof Damage", "Room Damage"), ("Cat", "Birds"), ("Pay Day", "Pay Day"), ("Lottery", "Lottery"), ("Pay Day", "Pay Day"), ("Stock 1", "Stock 2"), ("Pay Day", "Pay Day"), ("Gifts", "Gifts"), ("Cruise", "Hiking"), ("Pay Day", "Pay Day"), ("Found Money", "Found Money"), ("Timeshare", "Land"), ("Pay Day", "Pay Day"), ("Found $100", "Found $100"), ("Millionare Mansions", "Countryside Acres")]
    

    
    data.move=0
    data.playerX=300
    data.playerY=635
    data.compX=300
    data.compY=635
    data.playerIndex=0
    data.compIndex=0
    data.player1=True
    data.computerOver=False
    data.playerOver=False
    data.popUp=data.pics1stPath[0]
    data.isPopUp=False
    data.callMP=False
    data.callTF=False
    data.player1Dec=""
    data.compDec=""
    data.timer=0
    data.angle=math.pi/2
    data.randCount=0
    data.rotX=265
    data.rotY=525
    data.rotRad=14
    data.paused=False
    data.cx=333
    data.cy=540
    data.tempPlayX=300
    data.tempPlayY=635
    data.tempCompX=300
    data.tempCompY=635
    
    data.playerScore=100000
    data.compScore=100000

####################################
# mode dispatcher
####################################

def mousePressed(event, data):
    if (data.mode == "startScreen"): startScreenMousePressed(event, data)
    elif (data.mode == "playGameEasy"):   playGameEasyMousePressed(event, data)
    elif (data.mode == "playGameMedium"): playGameMediumMousePressed(event, data)
    elif (data.mode == "playGameHard"): playGameHardMousePressed(event, data)
    elif (data.mode == "help"):       helpMousePressed(event, data)
    elif (data.mode == "gameOver"):   gameOverMousePressed(event, data)


def keyPressed(event, data):
    if (data.mode == "startScreen"): startScreenKeyPressed(event, data)
    elif (data.mode == "playGameEasy"):   playGameEasyKeyPressed(event, data)
    elif (data.mode == "playGameMedium"):   playGameMediumKeyPressed(event, data)
    elif (data.mode == "playGameHard"):   playGameHardKeyPressed(event, data)
    elif (data.mode == "help"):       helpKeyPressed(event, data)
    elif (data.mode == "gameOver"):   gameOverKeyPressed(event, data)

def timerFired(data):
    if (data.mode == "startScreen"): startScreenTimerFired(data)
    elif (data.mode == "playGameEasy"):   playGameEasyTimerFired(data)
    elif (data.mode == "playGameMedium"):   playGameMediumTimerFired(data)
    elif (data.mode == "playGameHard"):   playGameHardTimerFired(data)
    elif (data.mode == "help"):       helpTimerFired(data)
    elif (data.mode == "gameOver"):   gameOverTimerFired(data)

def redrawAll(canvas, data):
    if (data.mode == "startScreen"): startScreenRedrawAll(canvas, data)
    elif (data.mode == "playGameEasy"):   playGameEasyRedrawAll(canvas, data)
    elif (data.mode == "playGameMedium"):   playGameMediumRedrawAll(canvas, data)
    elif (data.mode == "playGameHard"):   playGameHardRedrawAll(canvas, data)
    elif (data.mode == "help"):       helpRedrawAll(canvas, data)
    elif (data.mode == "gameOver"):   gameOverRedrawAll(canvas, data)
        
####################################
# startScreen mode
####################################

def startScreenMousePressed(event, data):
    if (80<event.x<300 and 200<event.y<275):
        data.mode="help"
        data.level="playGameEasy"
    elif (360<event.x<580 and 200<event.y<275):
        data.mode="help"
        data.level="playGameMedium"
    elif (640<event.x<870 and 200<event.y<275):
        data.mode="help"
        data.level="playGameHard"

def startScreenKeyPressed(event, data):
    data.mode="gameOver"
   
    
def startScreenTimerFired(data):
    pass

def startScreenRedrawAll(canvas, data):
    canvas.create_image(0,0, image=data.startScreenImg, anchor=NW)

    
####################################
# help mode
####################################

def helpMousePressed(event, data):
    data.mode=data.level

def helpKeyPressed(event, data):
    data.mode = data.level

def helpTimerFired(data):
    pass

def helpRedrawAll(canvas, data):
    canvas.create_image(0, 0, image=data.helpBack, anchor=NW)
    
####################################
# playGameEasy mode
####################################

def playGameEasyMousePressed(event, data):
    if (event.x<600):
        data.isPopUp=False
    elif (642<event.x<961 and 616<event.y<727):
        data.paused=False
    elif (data.callMP):
        data.paused=True
        makeMoves(data,event)

def playGameEasyKeyPressed(event, data):
    if (event.keysym == 'h'):
        data.mode = "help"
    elif (event.keysym == "r"):
        init(data)

def makeMoves(data,event):
    data.isPopUp=True
    data.move=random.randint(1,5)
    if (data.player1):
        tempIndexP=moveCarEasy(data)
        if (tempIndexP<= len(data.pos1stList)):
            popUpEasy(data, data.playerIndex)
            player1DecisionsEasy(data, event)
        else:
            data.playerOver=True
        data.player1=False
    else:
        tempIndex=moveCompEasy(data)
        if (tempIndex<=len(data.pos1stList)):
            popUpEasy(data, data.compIndex)
            compDecisionsEasy(data)
        else:
            data.computerOver=True
        data.player1=True
    checkGameOverEasy(data) 
    
def moveCarEasy(data):
    data.playerIndex+=data.move
    if (data.playerIndex<len(data.pos1stList)):
        data.tempPlayX=data.pos1stList[data.playerIndex][0]
        data.tempPlayY=data.pos1stList[data.playerIndex][1]
    return data.playerIndex
    
def moveCompEasy(data):
    data.compIndex+=data.move
    if (data.compIndex<len(data.pos1stList)):
        data.tempCompX=data.pos1stList[data.compIndex][0]
        data.tempCompY=data.pos1stList[data.compIndex][1]
    return data.compIndex
    

def popUpEasy(data, index):
    data.popUp=data.pics1stPath[index]
    
def player1DecisionsEasy(data, event):
    if (event.x<300):
        dec=data.money1stPath[data.playerIndex][0]
        data.playerScore+=dec
        data.player1Dec=data.dec1stPath[data.playerIndex][0]
    else:
        dec=data.money1stPath[data.playerIndex][1]
        data.playerScore+=dec
        data.player1Dec=data.dec1stPath[data.playerIndex][1]


def compDecisionsEasy(data):
    data.compCount+=1
    if (data.compCount%4==0):
        randComp=random.randint(0,1)
        dec=data.money1stPath[data.compIndex][randComp]
        data.compDec=data.dec1stPath[data.compIndex][randComp]
    else:
        dec=data.money1stPath[data.compIndex][0]
        data.compDec=data.dec1stPath[data.compIndex][0]
    data.compScore+=dec

def checkGameOverEasy(data):
    if (data.computerOver and data.playerOver):
        data.mode="gameOver"
        
def playGameEasyTimerFired(data):
    data.timer+=1
    data.randCount=random.randint(5,10)
    if (data.timer%data.randCount==0):
        data.paused=True
        data.callMP=True
    if (not data.paused):
        data.angle+=(math.pi/8)
        data.rotX=100*math.cos(data.angle)+data.cx
        data.rotY=100*math.sin(data.angle)+data.cy
    if (data.playerX<data.tempPlayX and data.playerY< data.tempPlayY):
        data.playerX+=2
        data.playerY+=2
    elif (data.playerX< data.tempPlayX and data.playerY > data.tempPlayY):
        data.playerX+=2
        data.playerY-=2
    elif (data.playerX> data.tempPlayX and data.playerY > data.tempPlayY):
        data.playerX-=2
        data.playerY-=2
    elif (data.playerX > data.tempPlayX and data.playerY < data.tempPlayY):
        data.playerX-=2
        data.playerY+=2
    if (data.compX<data.tempCompX and data.compY< data.tempCompY):
        data.compX+=2
        data.compY+=2
    elif (data.compX< data.tempCompX and data.compY > data.tempCompY):
        data.compX+=2
        data.compY-=2
    elif (data.compX> data.tempCompX and data.compY > data.tempCompY):
        data.compX-=2
        data.compY-=2
    elif (data.compX > data.tempCompX and data.compY < data.tempCompY):
        data.compX-=2
        data.compY+=2
    
def playGameEasyRedrawAll(canvas, data):
    canvas.create_image(0,0, image=data.board, anchor=NW)
    canvas.create_oval(data.rotX+data.rotRad, data.rotY+data.rotRad, data.rotX-data.rotRad, data.rotY-data.rotRad, fill="black")
    canvas.create_image(245, 452, image=data.spinner, anchor=NW)
    canvas.create_image(data.playerX,data.playerY, image=data.player, anchor=NW)
    canvas.create_image(data.compX, data.compY, image=data.computer, anchor=NW)
    canvas.create_image(600, 0, image=data.sideBar, anchor=NW)
    canvas.create_text(800, 120, text=str(data.player1Dec), font= "Arial 40", fill="white")
    canvas.create_text(800, 270, text=str(data.playerScore), font= "Arial 40", fill="white")
    canvas.create_text(800, 400, text=str(data.compDec), font= "Arial 40", fill= "white")
    canvas.create_text(800, 540, text=str(data.compScore), font= "Arial 40", fill="white")
    if (data.isPopUp):
        canvas.create_image(100, 200, image=data.popUp, anchor=NW)
    
####################################
# playGameMedium mode
####################################

def playGameMediumMousePressed(event, data):
    if (event.x<600):
        data.isPopUp=False
    elif (642<event.x<961 and 616<event.y<727):
        data.paused=False
    elif (data.callMP):
        data.paused=True
        makeMovesMed(data,event)

def playGameMediumKeyPressed(event, data):
    if (event.keysym == 'h'):
        data.mode = "help"
    elif (event.keysym == "r"):
        init(data)

def makeMovesMed(data,event):
    data.isPopUp=True
    data.move=random.randint(1,5)
    if (data.player1):
        tempIndexP=moveCarMedium(data)
        if (tempIndexP<= len(data.pos1stList)):
            popUpMedium(data, data.playerIndex)
            player1DecisionsMedium(data, event)
        else:
            data.playerOver=True
        data.player1=False
    else:
        tempIndex=moveCompMedium(data)
        if (tempIndex<=len(data.pos1stList)):
            popUpMedium(data, data.compIndex)
            compDecisionsMedium(data)
        else:
            data.computerOver=True
        data.player1=True
    checkGameOverMedium(data) 
    
def moveCarMedium(data):
    data.playerIndex+=data.move
    if (data.playerIndex<len(data.pos1stList)):
        data.tempPlayX=data.pos1stList[data.playerIndex][0]
        data.tempPlayY=data.pos1stList[data.playerIndex][1]
    return data.playerIndex
    
def moveCompMedium(data):
    data.compIndex+=data.move
    if (data.compIndex<len(data.pos1stList)):
        data.tempCompX=data.pos1stList[data.compIndex][0]
        data.tempCompY=data.pos1stList[data.compIndex][1]
    return data.compIndex
    

def popUpMedium(data, index):
    data.popUp=data.pics1stPath[index]
    
def player1DecisionsMedium(data, event):
    if (event.x<300):
        print ("yes")
        dec=data.money1stPath[data.playerIndex][0]
        data.playerScore+=dec
        data.player1Dec=data.dec1stPath[data.playerIndex][0]
    else:
        dec=data.money1stPath[data.playerIndex][1]
        data.playerScore+=dec
        data.player1Dec=data.dec1stPath[data.playerIndex][1]


def compDecisionsMedium(data):
    randComp=random.randint(0,1)
    dec=data.money1stPath[data.compIndex][randComp]
    data.compDec=data.dec1stPath[data.compIndex][randComp]
    data.compScore+=dec
    

def checkGameOverMedium(data):
    if (data.computerOver and data.playerOver):
        data.mode="gameOver"
        
def playGameMediumTimerFired(data):
    data.timer+=1
    data.randCount=random.randint(5,10)
    if (data.timer%data.randCount==0):
        data.paused=True
        data.callMP=True
    if (not data.paused):
        data.angle+=(math.pi/8)
        data.rotX=100*math.cos(data.angle)+data.cx
        data.rotY=100*math.sin(data.angle)+data.cy
    if (data.playerX<data.tempPlayX and data.playerY< data.tempPlayY):
        data.playerX+=2
        data.playerY+=2
    elif (data.playerX< data.tempPlayX and data.playerY > data.tempPlayY):
        data.playerX+=2
        data.playerY-=2
    elif (data.playerX> data.tempPlayX and data.playerY > data.tempPlayY):
        data.playerX-=2
        data.playerY-=2
    elif (data.playerX > data.tempPlayX and data.playerY < data.tempPlayY):
        data.playerX-=2
        data.playerY+=2
    if (data.compX<data.tempCompX and data.compY< data.tempCompY):
        data.compX+=2
        data.compY+=2
    elif (data.compX< data.tempCompX and data.compY > data.tempCompY):
        data.compX+=2
        data.compY-=2
    elif (data.compX> data.tempCompX and data.compY > data.tempCompY):
        data.compX-=2
        data.compY-=2
    elif (data.compX > data.tempCompX and data.compY < data.tempCompY):
        data.compX-=2
        data.compY+=2
    
def playGameMediumRedrawAll(canvas, data):
    canvas.create_image(0,0, image=data.board, anchor=NW)
    canvas.create_oval(data.rotX+data.rotRad, data.rotY+data.rotRad, data.rotX-data.rotRad, data.rotY-data.rotRad, fill="black")
    canvas.create_image(245, 452, image=data.spinner, anchor=NW)
    canvas.create_image(data.playerX,data.playerY, image=data.player, anchor=NW)
    canvas.create_image(data.compX, data.compY, image=data.computer, anchor=NW)
    canvas.create_image(600, 0, image=data.sideBar, anchor=NW)
    canvas.create_text(800, 120, text=str(data.player1Dec), font= "Arial 40", fill="white")
    canvas.create_text(800, 270, text=str(data.playerScore), font= "Arial 40", fill="white")
    canvas.create_text(800, 400, text=str(data.compDec), font= "Arial 40", fill= "white")
    canvas.create_text(800, 540, text=str(data.compScore), font= "Arial 40", fill="white")
    if (data.isPopUp):
        canvas.create_image(100, 200, image=data.popUp, anchor=NW)
        
        
####################################
# playGameHard mode
####################################

def playGameHardMousePressed(event, data):
    if (event.x<600):
        data.isPopUp=False
    elif (642<event.x<961 and 616<event.y<727):
        data.paused=False
    elif (data.callMP):
        data.paused=True
        makeMovesHard(data,event)

def playGameHardKeyPressed(event, data):
    if (event.keysym == 'h'):
        data.mode = "help"
    elif (event.keysym == "r"):
        init(data)

def makeMovesHard(data,event):
    data.isPopUp=True
    data.move=random.randint(1,5)
    if (data.player1):
        tempIndexP=moveCarHard(data)
        if (tempIndexP<= len(data.pos1stList)):
            popUpHard(data, data.playerIndex)
            player1DecisionsHard(data, event)
        else:
            data.playerOver=True
        data.player1=False
    else:
        tempIndex=moveCompHard(data)
        if (tempIndex<=len(data.pos1stList)):
            popUpHard(data, data.compIndex)
            compDecisionsHard(data)
        else:
            data.computerOver=True
        data.player1=True
    checkGameOverHard(data) 
    
def moveCarHard(data):
    data.playerIndex+=data.move
    if (data.playerIndex<len(data.pos1stList)):
        data.tempPlayX=data.pos1stList[data.playerIndex][0]
        data.tempPlayY=data.pos1stList[data.playerIndex][1]
    return data.playerIndex
    
def moveCompHard(data):
    data.compIndex+=data.move
    if (data.compIndex<len(data.pos1stList)):
        data.tempCompX=data.pos1stList[data.compIndex][0]
        data.tempCompY=data.pos1stList[data.compIndex][1]
    return data.compIndex
    

def popUpHard(data, index):
    data.popUp=data.pics1stPath[index]
    
def player1DecisionsHard(data, event):
    if (event.x<300):
        dec=data.money1stPath[data.playerIndex][0]
        data.playerScore+=dec
        data.player1Dec=data.dec1stPath[data.playerIndex][0]
    else:
        dec=data.money1stPath[data.playerIndex][1]
        data.playerScore+=dec
        data.player1Dec=data.dec1stPath[data.playerIndex][1]


def compDecisionsHard(data):
    data.compCount+=1
    if (data.compCount%4==0):
        randComp=random.randint(0,1)
        dec=data.money1stPath[data.compIndex][randComp]
        data.compDec=data.dec1stPath[data.compIndex][randComp]
    else:
        dec=data.money1stPath[data.compIndex][1]
        data.compDec=data.dec1stPath[data.compIndex][1]
    data.compScore+=dec

def checkGameOverHard(data):
    if (data.computerOver and data.playerOver):
        data.mode="gameOver"
        
def playGameHardTimerFired(data):
    data.timer+=1
    data.randCount=random.randint(5,10)
    if (data.timer%data.randCount==0):
        data.paused=True
        data.callMP=True
    if (not data.paused):
        data.angle+=(math.pi/8)
        data.rotX=100*math.cos(data.angle)+data.cx
        data.rotY=100*math.sin(data.angle)+data.cy
    if (data.playerX<data.tempPlayX and data.playerY< data.tempPlayY):
        data.playerX+=2
        data.playerY+=2
    elif (data.playerX< data.tempPlayX and data.playerY > data.tempPlayY):
        data.playerX+=2
        data.playerY-=2
    elif (data.playerX> data.tempPlayX and data.playerY > data.tempPlayY):
        data.playerX-=2
        data.playerY-=2
    elif (data.playerX > data.tempPlayX and data.playerY < data.tempPlayY):
        data.playerX-=2
        data.playerY+=2
    if (data.compX<data.tempCompX and data.compY< data.tempCompY):
        data.compX+=2
        data.compY+=2
    elif (data.compX< data.tempCompX and data.compY > data.tempCompY):
        data.compX+=2
        data.compY-=2
    elif (data.compX> data.tempCompX and data.compY > data.tempCompY):
        data.compX-=2
        data.compY-=2
    elif (data.compX > data.tempCompX and data.compY < data.tempCompY):
        data.compX-=2
        data.compY+=2
    
def playGameHardRedrawAll(canvas, data):
    canvas.create_image(0,0, image=data.board, anchor=NW)
    canvas.create_oval(data.rotX+data.rotRad, data.rotY+data.rotRad, data.rotX-data.rotRad, data.rotY-data.rotRad, fill="black")
    canvas.create_image(245, 452, image=data.spinner, anchor=NW)
    canvas.create_image(data.playerX,data.playerY, image=data.player, anchor=NW)
    canvas.create_image(data.compX, data.compY, image=data.computer, anchor=NW)
    canvas.create_image(600, 0, image=data.sideBar, anchor=NW)
    canvas.create_text(800, 120, text=str(data.player1Dec), font= "Arial 40", fill="white")
    canvas.create_text(800, 270, text=str(data.playerScore), font= "Arial 40", fill="white")
    canvas.create_text(800, 400, text=str(data.compDec), font= "Arial 40", fill= "white")
    canvas.create_text(800, 540, text=str(data.compScore), font= "Arial 40", fill="white")
    if (data.isPopUp):
        canvas.create_image(100, 200, image=data.popUp, anchor=NW)

####################################
# gameOver mode 
####################################

def gameOverMousePressed(event, data):
    print (event.x, event.y)

def gameOverKeyPressed(event, data):
    data.mode = data.level

def gameOverTimerFired(data):
    pass

def gameOverRedrawAll(canvas, data):
    canvas.create_image(0,0, image=data.gameOverImg, anchor=NW)
    if (data.playerScore>data.compScore):
        canvas.create_text(646, 234, text="Player 1", font= "Arial 40", fill="white")
        canvas.create_text(651, 475, text="$%d" %data.playerScore, font="Arial 40", fill="white")
    else:
        canvas.create_text(646, 234, text="The computer", font= "Arial 40", fill="black")
        canvas.create_text(651, 475, text="$%d" %data.compScore, font= "Arial 40", fill="white")
    
     
####################################
# use the run function as-is
####################################

def run(width=300, height=300):
    def redrawAllWrapper(canvas, data):
        canvas.delete(ALL)
        canvas.create_rectangle(0, 0, data.width, data.height,
                                fill='white', width=0)
        redrawAll(canvas, data)
        canvas.update()    

    def mousePressedWrapper(event, canvas, data):
        mousePressed(event, data)
        redrawAllWrapper(canvas, data)

    def keyPressedWrapper(event, canvas, data):
        keyPressed(event, data)
        redrawAllWrapper(canvas, data)

    def timerFiredWrapper(canvas, data):
        timerFired(data)
        redrawAllWrapper(canvas, data)
        # pause, then call timerFired again
        canvas.after(data.timerDelay, timerFiredWrapper, canvas, data)
    # Set up data and call init
    class Struct(object): pass
    data = Struct()
    data.width = width
    data.height = height
    data.timerDelay = 100 # milliseconds
    root = Tk()
    root.resizable(width=False, height=False) # prevents resizing window
    init(data)
    # create the root and the canvas
    canvas = Canvas(root, width=data.width, height=data.height)
    canvas.configure(bd=0, highlightthickness=0)
    canvas.pack()
    # set up events
    root.bind("<Button-1>", lambda event:
                            mousePressedWrapper(event, canvas, data))
    root.bind("<Key>", lambda event:
                            keyPressedWrapper(event, canvas, data))
    timerFiredWrapper(canvas, data)
    # and launch the app
    root.mainloop()  # blocks until window is closed
    print("bye!")

run(1000, 800)