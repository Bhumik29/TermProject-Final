# Updated Animation Starter Code

from tkinter import *
import math 
import random 

####################################
# customize these functions
####################################

def init(data):
    data.radius=25
    data.cx=200
    data.cy=200
    

def mousePressed(event, data):
    # use event.x and event.y
    pass

def keyPressed(event, data):
    # use event.char and event.keysym
    pass

def timerFired(data):
def player1DecisionsMed(data, event):
    if (event.x<300):
        dec=data.money1stPath[data.playerIndex][0]
        data.playerScore+=dec
    else:
        dec=data.money1stPath[data.playerIndex][1]
        data.playerScore+=dec
        
        
def player1DecisionsHard(data, event):
    if (event.x<300):
        dec=data.money1stPath[data.playerIndex][0]
        data.playerScore+=dec
    else:
        dec=data.money1stPath[data.playerIndex][1]
        data.playerScore+=dec
    

def redrawAll(canvas, data):
    canvas.create_oval(data.cx+data.radius, data.cy+data.radius, data.cx-data.radius, data.cy-data.radius, fill="black" )
   

####################################
# use the run function as-is
####################################

def run(width=300, height=300):
    def redrawAllWrapper(canvas, data):
        canvas.delete(ALL)
        canvas.create_rectangle(0, 0, data.width, data.height,
                                fill='white', width=0)
        redrawAll(canvas, data)
        canvas.update()    

    def mousePressedWrapper(event, canvas, data):
        mousePressed(event, data)
        redrawAllWrapper(canvas, data)

    def keyPressedWrapper(event, canvas, data):
        keyPressed(event, data)
        redrawAllWrapper(canvas, data)

    def timerFiredWrapper(canvas, data):
        timerFired(data)
        redrawAllWrapper(canvas, data)
        # pause, then call timerFired again
        canvas.after(data.timerDelay, timerFiredWrapper, canvas, data)
    # Set up data and call init
    class Struct(object): pass
    data = Struct()
    data.width = width
    data.height = height
    data.timerDelay = 100 # milliseconds
    root = Tk()
    root.resizable(width=False, height=False) # prevents resizing window
    init(data)
    # create the root and the canvas
    canvas = Canvas(root, width=data.width, height=data.height)
    canvas.configure(bd=0, highlightthickness=0)
    canvas.pack()
    # set up events
    root.bind("<Button-1>", lambda event:
                            mousePressedWrapper(event, canvas, data))
    root.bind("<Key>", lambda event:
                            keyPressedWrapper(event, canvas, data))
    timerFiredWrapper(canvas, data)
    # and launch the app
    root.mainloop()  # blocks until window is closed
    print("bye!")

run(400, 400)