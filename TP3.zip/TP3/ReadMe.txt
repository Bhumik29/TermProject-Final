READ ME:

Project Name: The Game of Life!

My term project is a recreation of the popular board game, the Game of Life. The objective of the game is very similar to the original board game. A player completes the journey through life, achieving important milestones such as graduating college, getting married, and having children. As the player progresses through life they are faced with decisions and hardships, and the game ends after the player achieves retirement. Life is typically multiplayer, and in my project, a player will be able to play against the computer or with another player. If playing against the computer, there is an easy, medium, or hard mode, and the computer will make informed decisions to achieve the best outcome for itself. The goal of the game is to retire with the most amount of money, and at the end the player with the most money wins. 

How to Run the Project: Open the file titled "TP3" in the IDE and run the file. In order to experience the full game, the file must be in the same folder as all of the pictures and audio included in the zipped folder. 

Install Libraries: To hear the audio, pygame must be installed. 

Shortcut Commands: To end the game, press the "z" key at any time. To restart the game, select "r" and to view the help screen, select "h". 
